module.exports = {
    API_KEY_RM_BG: "YOUR_API_KEY",
    API_KEY_OPEN_AI: "YOUR_API_KEY"
}